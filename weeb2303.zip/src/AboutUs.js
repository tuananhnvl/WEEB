import React from 'react';



function AboutUs() {
   
    return (
        <>
          <h2>VỀ CHÚNG TÔI</h2>
            
        </>

    );
};
export default AboutUs;