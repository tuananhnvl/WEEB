import React from 'react';

import BtnSeeMore from './component/BtnSeeMore'

function Services() {
   
    return (
        <>
          <h2> 3 Services</h2>
            <ul>
                <li>Dịch vụ thiết kế web</li>
                <li>Dịch vụ thiết kế thương hiệu</li>
                <li>Dịch vụ SEO</li>
            </ul>
            <BtnSeeMore/>
        </>

    );
};
export default Services;